
String saveUserID = "user_id";
String saveUserName = "user_name";
String saveUserEmail = "user_email";
String saveUserFirst = "user_first";
String saveUserLast = "user_last";
String saveUserStatus = "user_status";
String saveUserPassword = "user_password";
String saveUserLat = "user_Location1";
String saveUserLon = "user_Location2";