
import 'dart:ui';

import 'package:flutter/material.dart';

Color primary = Color(0xFF4d40fa);
Color backgroundColor = Color(0xFF1a125f);
Color greyColor = Color(0xFF454545);
Color redColor = Color(0xFFF43737);
Color buttonColor = Color(0xFFe6543a);
const Color loaderColor = Color.fromRGBO(194, 39, 45, 1);
const Color loadBackgroundColor = Colors.black;
