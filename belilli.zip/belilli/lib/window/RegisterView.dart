
import 'package:belilli/Model/RequestModel/RegisterRequestModel.dart';
import 'package:belilli/Model/ResponseModel/RegisterResponse.dart';
import 'package:belilli/api/ObjectController.dart';
import 'package:belilli/appcomman/AppUtil.dart';
import 'package:belilli/window/LoginView.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../appcomman/AppColor.dart';
import '../appcomman/AppVariable.dart';
import '../view/SplashScreen.dart';
import 'Enjoy1.dart';

class RegisterView extends StatefulWidget{
  const RegisterView({super.key});


  @override
  State<StatefulWidget> createState() =>_RegisterView();
}

class _RegisterView extends State<RegisterView> {
  
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController cnfPassword = TextEditingController();
  TextEditingController fName = TextEditingController();
  TextEditingController lName = TextEditingController();

  bool isLoading  = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();


  }


  Future<bool> _onWillPop() async {
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) =>  SplashScreen()),
        ModalRoute.withName("/splashView")

    );
    return true; //
  }
  @override
  Widget build(BuildContext context) {
   return WillPopScope(
     onWillPop: _onWillPop,
     child: Scaffold(
       body: SafeArea(
         child: Container(
           height: double.infinity,
           width: double.infinity,
           decoration: BoxDecoration(
               image: DecorationImage(
                   fit: BoxFit.fill,
                   image: AssetImage("images/splash.png")
               )
           ),
           child: Column(
             crossAxisAlignment: CrossAxisAlignment.start,
             mainAxisAlignment: MainAxisAlignment.spaceBetween,
             children: [
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal: 10.0,vertical: 15),
                 child: IconButton(onPressed: (){
                   _onWillPop();
                 }, icon: Icon(Icons.arrow_back,color: Colors.white,)),
               ),
               Align(
                 alignment: Alignment.bottomCenter,
                 child: Container(

                   width: double.infinity,
                   padding: EdgeInsets.symmetric(horizontal: 35),
                   decoration: BoxDecoration(
                       borderRadius: BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15)),
                       color: Colors.white
                   ),
                   child: Column(
                     crossAxisAlignment: CrossAxisAlignment.start,
                     mainAxisSize: MainAxisSize.min,
                     children: [
                       SizedBox(height: 33,),
                       Center(
                         child: Text("Register",
                           textAlign: TextAlign.center,
                           style: TextStyle(fontSize: 23,color: primary,fontWeight: FontWeight.bold),),
                       ),
                       SizedBox(height: 15,),
                       Padding(
                         padding: const EdgeInsets.symmetric(horizontal: 0.0,vertical: 8),
                         child: SizedBox(
                           height: 45,
                           child: TextField(

                             controller: fName,
                             keyboardType: TextInputType.text,
                             decoration: InputDecoration(
                               hintText: 'First name',
                               hintStyle: TextStyle(fontSize: 13,fontWeight: FontWeight.w800,color: Color(0xFF454545)),
                               enabledBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),
                               focusedBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),



                               border: OutlineInputBorder(
                                   borderSide: BorderSide(color: Colors.green,width: 0.4),
                                   borderRadius: BorderRadius.circular(15)
                               ),
                               filled: true,
                               contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                               fillColor: Color(0xFFF8F9FA),
                             ),
                           ),
                         ),
                       ),
                       Padding(
                         padding: const EdgeInsets.symmetric(horizontal: 0.0,vertical: 8),
                         child: SizedBox(
                           height: 45,
                           child: TextField(

                             controller: lName,
                             keyboardType: TextInputType.text,
                             decoration: InputDecoration(
                               hintText: 'Last name',
                               hintStyle: TextStyle(fontSize: 13,fontWeight: FontWeight.w800,color: Color(0xFF454545)),
                               enabledBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),
                               focusedBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),



                               border: OutlineInputBorder(
                                   borderSide: BorderSide(color: Colors.green,width: 0.4),
                                   borderRadius: BorderRadius.circular(15)
                               ),
                               filled: true,
                               contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                               fillColor: Color(0xFFF8F9FA),
                             ),
                           ),
                         ),
                       ),
                       Padding(
                         padding: const EdgeInsets.symmetric(horizontal: 0.0,vertical: 8),
                         child: SizedBox(
                           height: 45,
                           child: TextField(

                             controller: email,
                             keyboardType: TextInputType.text,
                             decoration: InputDecoration(
                               hintText: 'Email address',
                               hintStyle: TextStyle(fontSize: 13,fontWeight: FontWeight.w800,color: Color(0xFF454545)),
                               enabledBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),
                               focusedBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),



                               border: OutlineInputBorder(
                                   borderSide: BorderSide(color: Colors.green,width: 0.4),
                                   borderRadius: BorderRadius.circular(15)
                               ),
                               filled: true,
                               contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                               fillColor: Color(0xFFF8F9FA),
                             ),
                           ),
                         ),
                       ),
                       Padding(
                         padding: const EdgeInsets.symmetric(horizontal: 0.0,vertical: 8),
                         child: SizedBox(
                           height: 45,
                           child: TextField(

                             controller: password,
                             keyboardType: TextInputType.text,
                             decoration: InputDecoration(
                               hintText: 'Password',
                               hintStyle: TextStyle(fontSize: 13,fontWeight: FontWeight.w800,color: Color(0xFF454545)),
                               enabledBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),
                               focusedBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),



                               border: OutlineInputBorder(
                                   borderSide: BorderSide(color: Colors.green,width: 0.4),
                                   borderRadius: BorderRadius.circular(15)
                               ),
                               filled: true,
                               contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                               fillColor: Color(0xFFF8F9FA),
                             ),
                           ),
                         ),
                       ),

                       Padding(
                         padding: const EdgeInsets.symmetric(horizontal: 0.0,vertical: 8),
                         child: SizedBox(
                           height: 45,
                           child: TextField(

                             controller: cnfPassword,
                             keyboardType: TextInputType.text,
                             decoration: InputDecoration(
                               hintText: 'Confirm Password',
                               hintStyle: TextStyle(fontSize: 13,fontWeight: FontWeight.w800,color: Color(0xFF454545)),
                               enabledBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),
                               focusedBorder: OutlineInputBorder(
                                 borderRadius: BorderRadius.all(Radius.circular(12.0)),
                                 borderSide: BorderSide(color: Color(0xFFdbd3f4), width: 1),
                               ),



                               border: OutlineInputBorder(
                                   borderSide: BorderSide(color: Colors.green,width: 0.4),
                                   borderRadius: BorderRadius.circular(15)
                               ),
                               filled: true,
                               contentPadding: EdgeInsets.symmetric(vertical: 10,horizontal: 15),
                               fillColor: Color(0xFFF8F9FA),
                             ),
                           ),
                         ),
                       ),
                       SizedBox(height: 20,),

                       InkWell(
                         onTap: (){

                           if(fName.text.toString().trim().isEmpty)
                             {
                               AppUtil.showToast("Enter first name", "s");
                             }

                           else if(lName.text.toString().trim().isEmpty)
                             {
                               AppUtil.showToast("Enter last name", "s");
                             }

                           else if(email.text.toString().trim().isEmpty)
                             {
                               AppUtil.showToast("Enter email", "s");
                             }

                           else if(password.text.toString().trim().isEmpty)
                             {
                               AppUtil.showToast("Enter password", "s");
                             }

                           else if(cnfPassword.text.toString().trim().isEmpty)
                             {
                               AppUtil.showToast("Re-Enter password", "s");
                             }

                           else if(cnfPassword.text.toString().trim()!=password.text.toString().trim())
                             {
                               AppUtil.showToast("Password not same", "s");
                             }

                           else
                           {
                             RegisterRequestModel requestModel = RegisterRequestModel("", "", "", "", "", "");

                             requestModel.first_name = fName.text.toString().trim();
                             requestModel.last_name = lName.text.toString().trim();
                             requestModel.username = email.text.toString().trim();
                             requestModel.password = password.text.toString().trim();

                             ObjectController controller = ObjectController();

                             setState(() {
                               isLoading=  true;
                             });

                             controller.registerCallAPI(requestModel).then((value) async {

                               RegisterResponse response = value;

                               if(response.error==false && response.data!=null)
                                 {
                                   SharedPreferences sp = await SharedPreferences.getInstance();

                                   sp.setString(saveUserEmail, response.data!.email.toString());
                                   sp.setString(saveUserID, response.data!.id.toString());
                                   sp.setString(saveUserFirst, response.data!.firstName.toString());
                                   sp.setString(saveUserLast, response.data!.lastName.toString());
                                   sp.setString(saveUserStatus, response.data!.status.toString());
                                   sp.setString(saveUserPassword, response.data!.password.toString());

                                   AppUtil.showToast(response.message!, "s");


                                   Navigator.pushAndRemoveUntil(
                                       context,
                                       MaterialPageRoute(builder: (context) =>  Enjoy1()),
                                       ModalRoute.withName("/enjoy1")

                                   );
                                 }

                               setState(() {
                                 isLoading=  false;
                               });
                             });
                           }

                         },
                         child: Container(
                           width: double.infinity,
                           height: 40,
                           alignment: Alignment.center,
                           margin: EdgeInsets.symmetric(horizontal: 3,vertical: 0),
                           decoration: BoxDecoration(
                             borderRadius: BorderRadius.circular(12),
                             color: primary,
                           ),

                           child:isLoading ? Center(child: Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: CircularProgressIndicator(color: Colors.white,),
                           ),): Text("Register",style: TextStyle(fontSize: 16,color: Colors.white,fontWeight: FontWeight.w800),),
                         ),
                       ),

                       SizedBox(height: 15,),

                       Row(
                         mainAxisAlignment: MainAxisAlignment.center,
                         children: [
                           Text("Already have an account?",style: TextStyle(fontSize: 12,color: Color(0xFF454545),fontWeight: FontWeight.bold)),


                           SizedBox(width: 10,),

                           InkWell(
                               onTap: ()
                               {
                                 Navigator.push(context, MaterialPageRoute(builder: (context) => LoginView(),));
                               },
                               child: Text("Log in",style: TextStyle(fontSize: 12,color: Color(0xFFe6543a),fontWeight: FontWeight.bold))),
                         ],
                       ),

                       SizedBox(height: 15,),
                     ],
                   ),
                 ),
               ),
             ],
           ),
         ),
       ),

     ),
   );
  }
}