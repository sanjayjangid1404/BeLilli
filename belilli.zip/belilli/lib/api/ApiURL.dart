
String baseURL  = "belilli.co.uk"; 
String imageURL  = "http://belilli.co.uk";

String folder  = "/api.php";
String loginAPI = "function=login";