
import 'package:flutter/material.dart';

import '../../appcomman/AppColor.dart';
import '../../appcomman/AppRoute.dart';

class ActivityView extends StatefulWidget{
  const ActivityView({super.key});


  @override
  State<StatefulWidget> createState() =>_ActivityView();
}

class _ActivityView extends State<ActivityView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(

          height: double.infinity,
          width: double.infinity,
          color: backgroundColor,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 17.0),
              child: Column(
                children: [
                  SizedBox(height: 20,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Activity",style: TextStyle(fontSize: 18,color: Colors.white),),
                      InkWell(
                          onTap: (){
                            NavigationService.instance.navigateTo("/accountView");
                          },
                          child: ImageIcon(AssetImage("images/profile.png"),size: 27,color: Color(0xFFe6543a),))
                    ],
                  ),
                  SizedBox(height: 16,),

                  activityContainer(),
                  SizedBox(height: 16,),

                  // productList()
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget activityContainer()
  {
    return ListView.builder(
      itemCount: 10,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
      return Container(
        margin: EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: Colors.white
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0,vertical: 15),
          child: Row(
            children: [
              Expanded(
                  flex:1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Business name",style: TextStyle(fontSize: 12,color: greyColor),),
                      SizedBox(height: 6,),
                      Text("10% off hot drinks",style: TextStyle(fontSize: 11,color: redColor),),
                    ],
                  )),
              Expanded(
                flex:1,
                child: Align(
                    alignment: Alignment.topRight,
                    child: Text("12/04/2022",style: TextStyle(fontSize: 12,color: greyColor),)),
              )
            ],
          ),
        ),
      );
    },);
  }
}