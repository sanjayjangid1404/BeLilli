package com.edge.belilli

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
